<!DOCTYPE html> 
<html>
 <head>
<meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1">
 <style type="text/css">
{ padding: 0; margin: 0; } h2{ 	color:#50626C; 	text-align: center; 	font-family: arial; 	text-transform: uppercase; 	border: 5px solid #f1f1f1; 	padding: 5px; 	width: 300px; 	margin: auto; 	margin-bottom: 10px; margin-top: 20px; } form { border: 3px solid #f1f1f1; font-family: arial; width: 300px; margin: auto; } input[type=text], input[type=password] , input[type=number]{ width: 100%; padding: 12px 20px; margin: 8px 0; display: inline-block; border: 1px solid #ccc; box-sizing: border-box; } label{ 	color:#50626C; 	text-transform: uppercase; } button { background-color: #0ED1EF; color: white; padding: 14px 20px; margin: 8px 0; border: none; cursor: pointer; width: 100%; } button:hover { opacity: 0.8; } .cancelbtn { width: auto; padding: 10px 18px; background-color: #f03434; } .imgcontainer { text-align: center; margin: 24px 0 12px 0; } img.avatar { width: 40%; border-radius: 50%; } .container { padding: 16px; } span.psw { float: right; padding-top: 16px; } span{ 	color:#50626C; } /* Change styles for span and cancel button on extra small screens */ @media screen and (max-width: 300px) { span.psw { display: block; float: none; } .cancelbtn { width: 100%; } }
    </style>
<title>Nabila Tools</title>
<link rel="stylesheet" href="style.css" type="text/css">
</head>
<body>
</head>
<!-- Bootstrap -->
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
<body>
  </head>
  <body>
<div class="container"><center>
<br/><h3>Nabila Tools <span class="label label-primary">Sms icq</span></h3>
<hr/>
<body>
<marquee behavior="alternate" onmouseover="this.stop()" onmouseout="this.start()"><font color=#000000">[+] Thanks to Keizer404 [+]</font></marquee>
<br>
	</script> 
</html>
Example : 6287714070299 Support all Country Phone Number
<br>
<br>
<form action="http://nabila-tools.xyz/api/icq.php" method="Get">
<div class="container"> 
<label><b>No HP</b></label> <input type="text" placeholder="No HP 6287714070299" name="no" id="no" value="" required> 

<label><b>Jumlah sms</b></label> <input type="number" placeholder="Jumlah (1 - 99) " name="loop" id="loop" required> 
	
<button type="submit">Mulai Bom</button>
<br><br><br>
<center>
<h5>Created By : 
<a href="https://m.facebook.com/m.1khe4n">Muhammad Ikhsan</a>
</h5>
</center>
</body> </html>
<!doctype html public "-//W3C//DTD HTML 4.0 Transitional//EN">
<font color="black"><script type="text/javascript">
now = new Date();
if (now.getTimezoneOffset() == 0) (a=now.getTime() + ( 7 *60*60*1000))
else (a=now.getTime());
now.setTime(a);
var tahun= now.getFullYear ()
var hari= now.getDay ()
var bulan= now.getMonth ()
var tanggal= now.getDate ()
var hariarray=new Array("Minggu,","Senin,",
"Selasa,","Rabu,","Kamis,","Jum'at,","Sabtu,")
var bulanarray=new Array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","Nopember","/ 12 /")
document.write(hariarray[hari]+" "+tanggal+" "+bulanarray[bulan]+" "+tahun)
</script>
<script type="text/javascript">
now = new Date();
if (now.getTimezoneOffset() == 0) (a=now.getTime() + ( 7 *60*60*1000))
else (a=now.getTime());
now.setTime(a);
document.write(" Jam " + ((now.getHours() < 10) ? "0" : "") + now.getHours() + ":" + ((now.getMinutes() < 10)? "0" : "") + now.getMinutes() + (" W.I.B "))
</script>
</font>
<br>
	<br>